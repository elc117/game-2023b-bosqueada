# Bosqueada

## Mini Progresso Print
![Erro ao carregar a imagem](Bosqueada/assets/prints/Icone+cenario1.png)

### Ideia
   Adicionar perguntas no cenário, caso elas sejam respondidas corretamente o jogador recebe moedas e, com as moedas recebidas, ele poderá ir para o proximo cenário, onde terá que enfrentar novas perguntas.
